package TunaF.toyPjt_Login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToyPjtLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
