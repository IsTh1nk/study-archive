package TunaF.toyPjt_Login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyPjtLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToyPjtLoginApplication.class, args);
	}

}
